﻿

public class AppConstants
{
    public const string Addition = "Addition";
    public const string Geometry = "Geometry";
    public const string MixedOperations = "Mixed Operations";
    public const string NumberSense = "Number sense";
    public const string Subtraction = "Subtraction";
}
